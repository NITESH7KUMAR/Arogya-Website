const express = require('express')
const path = require('path')
const mongoose = require('mongoose')
const bcrypt = require('bcrypt');

const collection = require("./config")

const port = 3002

const app = express()

app.set('view engine', 'ejs')

app.use(express.json())

app.use(express.urlencoded({ extended: false }))
app.use(express.static("public"))

app.get('/', (req, res) => {
    res.render('login')
})

app.get('/signup', (req, res) => {
    res.render('signup')
})

app.post('/signup', async (req, res) => {
    const data ={
        name: req.body.username,
        password: req.body.password
    }

    const existingUser = await collection.findOne({name: data.name})
    if(existingUser){
        res.send("User already exists. Please choose a different username")
    }else{
        // hash th password using bcrypt

        const saltRounds = 10; // number of salt round bcrypt
        const hashedPassword = await bcrypt.hash(data.password, saltRounds)
        data.password = hashedPassword;

        const userdata= await collection.insertMany(data)
        console.log(userdata)
        res.send("User created successfully");
        
    }
})



app.post('/login', async (req, res) => {
    try {
        const user = await collection.findOne({ name: req.body.username });
        if (!user) {
            return res.send("User not found.");
        }

        const isPasswordMatch = await bcrypt.compare(req.body.password, user.password);
        if (isPasswordMatch) {
            res.render("home");
        } else {
            res.send("Wrong username or password");
        }
    } catch (error) {
        console.error(error);
        res.send("An error occurred.");
    }
});






app.listen(port, (req, res) => {
    console.log(`listening on port no: ${port}`);
})